package com.capgemini.ws;

import java.util.List;

import javax.jws.WebMethod;
import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;
import javax.jws.soap.SOAPBinding.Style;

import com.capgemini.entities.Product;
import com.capgemini.exception.ProductException;

@WebService
@SOAPBinding(style = Style.RPC)
public interface IProductService {

/*	@WebMethod
	public int addProduct(Product product) throws ProductException;
	@WebMethod
	public void updateProduct(Product product) throws ProductException;*/
	@WebMethod
	public Product getProduct(int id) throws ProductException;
	/*@WebMethod
	public void removeProduct(int id) throws ProductException;
	@WebMethod
	public List<Product> getAllProducts() throws ProductException;
	@WebMethod
	public Product getProductByName(String name) throws ProductException;
	@WebMethod
	public List<Product> getProductsByRange(float min,float max) throws ProductException;*/
}
