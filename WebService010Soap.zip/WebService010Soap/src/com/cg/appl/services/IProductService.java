package com.cg.appl.services;

public interface IProductService {

	
}
